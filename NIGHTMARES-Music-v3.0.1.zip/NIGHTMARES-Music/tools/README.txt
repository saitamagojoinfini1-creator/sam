Place ici yt-dlp.exe (optionnel mais recommande sur Windows)

Telechargement :
  https://github.com/yt-dlp/yt-dlp/releases
  -> fichier yt-dlp.exe

Sinon le serveur utilise : pip install yt-dlp
