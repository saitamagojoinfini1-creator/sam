@echo off
cd /d "%~dp0"
call LANCER-SERVEUR.bat
