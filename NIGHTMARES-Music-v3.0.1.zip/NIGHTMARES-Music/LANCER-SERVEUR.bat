@echo off
chcp 65001 >nul
title NIGHTMARES Music v3.0 - NE PAS FERMER
cd /d "%~dp0"
echo.
echo  ========================================
echo   NIGHTMARES Music v3.0
echo   Resultats illimites + API bot
echo  ========================================
echo.
where python >nul 2>&1
if %errorlevel%==0 (
  python -c "import yt_dlp" 2>nul
  if errorlevel 1 (
    echo  Installation yt-dlp...
    python -m pip install -U yt-dlp -q
  )
  start "" http://127.0.0.1:8765/
  python server.py
  goto :eof
)
where py >nul 2>&1
if %errorlevel%==0 (
  py -c "import yt_dlp" 2>nul
  if errorlevel 1 (
    echo  Installation yt-dlp...
    py -m pip install -U yt-dlp -q
  )
  start "" http://127.0.0.1:8765/
  py server.py
  goto :eof
)
echo Python manquant : https://www.python.org/downloads/
pause
