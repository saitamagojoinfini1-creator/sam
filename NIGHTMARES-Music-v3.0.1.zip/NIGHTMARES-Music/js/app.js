/**
 * NIGHTMARES Music v3.0 — illimité + paramètres + API keys
 */
(() => {
  const IS_HTTP = location.protocol.startsWith("http");
  const $ = (s) => document.querySelector(s);
  const form = $("#search-form");
  const input = $("#query");
  const btnSearch = $("#btn-search");
  const statusEl = $("#status");
  const resultsEl = $("#results");
  const metaEl = $("#results-meta");
  const countEl = $("#results-count");
  const player = $("#player");
  const audio = $("#audio");
  const libraryEl = $("#library");
  const banner = $("#file-banner");
  const lyricsPanel = $("#lyrics-panel");
  const lyricsBody = $("#lyrics-body");
  const lyricsTitle = $("#lyrics-title");
  const lyricsArtist = $("#lyrics-artist");

  let tracks = [];
  let sortMode = "pop";
  let lyricsPinned = false;
  const LIB_KEY = "nm-music-library-v3";

  if (banner) banner.hidden = IS_HTTP;

  function setStatus(msg, type = "normal") {
    statusEl.textContent = msg || "";
    statusEl.dataset.type = type;
  }
  function esc(s) {
    return String(s ?? "")
      .replace(/&/g, "&amp;").replace(/</g, "&lt;")
      .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }
  function loadLib() {
    try { return JSON.parse(localStorage.getItem(LIB_KEY) || "[]"); } catch { return []; }
  }
  function saveLib(list) {
    localStorage.setItem(LIB_KEY, JSON.stringify(list.slice(0, 120)));
  }
  function addToLib(track) {
    const list = loadLib().filter(x => !(x.title === track.title && x.artist === track.artist));
    list.unshift({
      title: track.title, artist: track.artist,
      thumbnail: track.thumbnail || "", duration: track.duration || "",
      preview: track.preview || "", addedAt: Date.now()
    });
    saveLib(list);
    renderLibrary();
  }

  function switchTab(name) {
    document.querySelectorAll(".tab").forEach((t) => t.classList.toggle("active", t.dataset.tab === name));
    document.querySelectorAll(".tab-panel").forEach((p) => {
      p.hidden = p.id !== "tab-" + name;
    });
    if (name === "settings") loadSettingsUI();
    if (name === "library") renderLibrary();
  }

  async function search(q) {
    if (!IS_HTTP) {
      setStatus("Lance python server.py puis ouvre http://127.0.0.1:8765", "error");
      return;
    }
    const limit = parseInt($("#limit-select").value || "200", 10);
    const artistMode = $("#artist-mode").checked;
    setStatus("Recherche" + (artistMode ? " discographie" : "") + "… (peut prendre quelques secondes)", "loading");
    btnSearch.disabled = true;
    try {
      let u = "/api/search?q=" + encodeURIComponent(q) + "&limit=" + limit;
      if (artistMode) u += "&artist=1";
      const ctrl = new AbortController();
      const t = setTimeout(() => ctrl.abort(), 60000);
      const res = await fetch(u, { signal: ctrl.signal });
      clearTimeout(t);
      const data = await res.json();
      tracks = (data.result || []).map((t, i) => ({ ...t, id: t.id || ("r" + i) }));
      if (!tracks.length) {
        setStatus("Aucun résultat.", "error");
        resultsEl.innerHTML = '<div class="empty">Aucun résultat.</div>';
        metaEl.hidden = true;
      } else {
        setStatus(tracks.length + " titre(s) trouvé(s)" + (data.total_hint ? " (Deezer total ≈ " + data.total_hint + ")" : ""), "ok");
        metaEl.hidden = false;
        countEl.textContent = tracks.length + " résultats";
        render();
      }
    } catch (e) {
      setStatus(e.name === "AbortError" ? "Timeout — réessaie." : "Erreur: " + e.message, "error");
    } finally {
      btnSearch.disabled = false;
    }
  }

  function sorted() {
    const arr = [...tracks];
    if (sortMode === "name") arr.sort((a, b) => (a.title || "").localeCompare(b.title || ""));
    else if (sortMode === "artist") arr.sort((a, b) => (a.artist || "").localeCompare(b.artist || ""));
    else arr.sort((a, b) => (b.popularity || 0) - (a.popularity || 0));
    return arr;
  }

  function cardHtml(t, lib = false) {
    return (
      '<article class="card" data-id="' + esc(String(t.id)) + '"' +
      ' data-title="' + esc(t.title) + '" data-artist="' + esc(t.artist) + '"' +
      ' data-thumb="' + esc(t.thumbnail || "") + '" data-duration="' + esc(t.duration || "") + '">' +
      '<img src="' + esc(t.thumbnail || "") + '" alt="" loading="lazy" onerror="this.style.opacity=0.3" />' +
      '<div class="card-info">' +
      '<div class="card-title">' + esc(t.title) + '</div>' +
      '<div class="card-sub">' + esc(t.artist) + (t.album ? " · " + esc(t.album) : "") +
      (t.duration ? " · " + esc(t.duration) : "") + '</div>' +
      '</div>' +
      '<div class="card-actions">' +
      '<button type="button" class="btn btn-play" data-action="play">▶ Écouter</button>' +
      '<button type="button" class="btn btn-dl" data-action="dl">⬇ MP3</button>' +
      '<button type="button" class="btn btn-ly" data-action="lyrics">♪ Paroles</button>' +
      '</div></article>'
    );
  }

  function render() {
    resultsEl.innerHTML = sorted().map((t) => cardHtml(t)).join("");
  }

  function renderLibrary() {
    const list = loadLib();
    if (!list.length) {
      libraryEl.innerHTML = '<div class="empty">Aucun téléchargement pour l’instant.</div>';
      return;
    }
    libraryEl.innerHTML = list.map((t, i) => cardHtml({ ...t, id: "lib-" + i }, true)).join("");
  }

  function showPlayer(track) {
    $("#player-title").textContent = track.title;
    $("#player-artist").textContent = track.artist;
    $("#player-art").src = track.thumbnail || "";
    player.hidden = false;
    player.style.display = "";
  }

  async function playOnly(track, btn) {
    if (!IS_HTTP) return setStatus("Serveur requis.", "error");
    const old = btn.textContent;
    btn.disabled = true;
    btn.textContent = "…";
    try {
      const q = (track.artist + " " + track.title).trim();
      const src =
        "/api/stream?q=" + encodeURIComponent(q) +
        "&title=" + encodeURIComponent(track.title || "") +
        "&artist=" + encodeURIComponent(track.artist || "");
      const head = await fetch(src, { method: "GET", headers: { Range: "bytes=0-1" } });
      if (!head.ok) {
        const err = await head.json().catch(() => ({}));
        throw new Error(err.error || "Lecture impossible");
      }
      audio.src = src;
      showPlayer(track);
      await audio.play();
      setStatus("Lecture : " + track.title, "ok");
    } catch (e) {
      setStatus(e.message || "Erreur lecture", "error");
    } finally {
      btn.disabled = false;
      btn.textContent = old;
    }
  }

  async function downloadOnly(track, btn) {
    if (!IS_HTTP) return setStatus("Serveur requis.", "error");
    const old = btn.textContent;
    btn.disabled = true;
    btn.textContent = "…";
    try {
      const q = (track.artist + " " + track.title).trim();
      const url =
        "/api/file?q=" + encodeURIComponent(q) +
        "&title=" + encodeURIComponent(track.title || "") +
        "&artist=" + encodeURIComponent(track.artist || "");
      const res = await fetch(url);
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || "Téléchargement impossible");
      }
      const blob = await res.blob();
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = (track.artist + " - " + track.title).replace(/[\\/:*?"<>|]/g, "") + ".mp3";
      a.click();
      URL.revokeObjectURL(a.href);
      addToLib(track);
      setStatus("Téléchargé : " + track.title, "ok");
    } catch (e) {
      setStatus(e.message || "Erreur DL", "error");
    } finally {
      btn.disabled = false;
      btn.textContent = old;
    }
  }

  async function showLyrics(track) {
    lyricsPanel.hidden = false;
    lyricsPanel.style.display = "flex";
    player.style.display = ""; // ensure player can show later
    lyricsTitle.textContent = track.title || "Paroles";
    lyricsArtist.textContent = track.artist || "";
    lyricsBody.textContent = "Chargement des paroles…";
    if (!IS_HTTP) {
      lyricsBody.textContent = "Serveur requis pour les paroles.";
      return;
    }
    try {
      const u =
        "/api/lyrics?artist=" + encodeURIComponent(track.artist || "") +
        "&title=" + encodeURIComponent(track.title || "");
      const res = await fetch(u);
      const data = await res.json();
      if (data.status && data.lyrics) {
        lyricsBody.textContent = data.lyrics;
      } else {
        lyricsBody.textContent = "Paroles introuvables pour « " + track.title + " ».";
      }
    } catch {
      lyricsBody.textContent = "Erreur de chargement des paroles.";
    }
  }

  function onCard(e) {
    const btn = e.target.closest("[data-action]");
    if (!btn) return;
    const card = btn.closest(".card");
    if (!card) return;
    const track = {
      id: card.dataset.id,
      title: card.dataset.title,
      artist: card.dataset.artist,
      thumbnail: card.dataset.thumb,
      duration: card.dataset.duration,
    };
    const full = tracks.find((x) => String(x.id) === String(track.id));
    if (full) Object.assign(track, full);
    if (btn.dataset.action === "play") playOnly(track, btn);
    if (btn.dataset.action === "dl") downloadOnly(track, btn);
    if (btn.dataset.action === "lyrics") showLyrics(track);
  }

  // ─── Settings / API keys ───────────────────────────────────────
  async function loadSettingsUI() {
    if (!IS_HTTP) return;
    try {
      const res = await fetch("/api/settings");
      const data = await res.json();
      const s = data.settings || {};
      $("#st-status").textContent = data.status ? "Connecté" : "Hors ligne";
      $("#st-status").className = "v " + (data.status ? "ok" : "bad");
      $("#st-version").textContent = data.version || "—";
      $("#st-ytdlp").textContent = data.ytdlp ? "OK" : "Manquant";
      $("#st-ytdlp").className = "v " + (data.ytdlp ? "ok" : "bad");
      $("#st-ffmpeg").textContent = data.ffmpeg ? "OK" : "Manquant (conseillé)";
      $("#st-ffmpeg").className = "v " + (data.ffmpeg ? "ok" : "bad");
      $("#opt-require-key").checked = s.require_api_key !== false;
      $("#opt-max-results").value = String(s.max_results || 200);
      $("#api-base").textContent = location.origin;

      const list = $("#keys-list");
      const keys = data.keys || [];
      if (!keys.length) {
        list.innerHTML = '<p class="hint">Aucune clé pour l’instant. Crée-en une pour ton bot.</p>';
      } else {
        list.innerHTML = keys.map((k) => {
          const created = k.created_at ? new Date(k.created_at * 1000).toLocaleString() : "—";
          const used = k.last_used ? new Date(k.last_used * 1000).toLocaleString() : "jamais";
          return (
            '<div class="key-row" data-full="' + esc(k.full_key || "") + '">' +
            '<div><strong>' + esc(k.name || "clé") + '</strong> · <code>' + esc(k.key) + '</code>' +
            '<div class="meta">Créée: ' + esc(created) + ' · Utilisations: ' + (k.uses || 0) + ' · Dernier: ' + esc(used) + '</div></div>' +
            '<button type="button" data-revoke="' + esc(k.full_key || "") + '">Révoquer</button></div>'
          );
        }).join("");
      }
    } catch (e) {
      $("#st-status").textContent = "Erreur";
      $("#st-status").className = "v bad";
    }
  }

  $("#btn-create-key")?.addEventListener("click", async () => {
    const name = ($("#key-name").value || "bot").trim();
    try {
      const res = await fetch("/api/keys/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name }),
      });
      const data = await res.json();
      if (!data.status) throw new Error(data.error || "échec");
      $("#new-key-box").hidden = false;
      $("#new-key-value").textContent = data.key;
      loadSettingsUI();
    } catch (e) {
      alert("Erreur création clé: " + e.message);
    }
  });

  $("#btn-copy-key")?.addEventListener("click", async () => {
    const v = $("#new-key-value").textContent;
    try {
      await navigator.clipboard.writeText(v);
      $("#btn-copy-key").textContent = "Copié !";
      setTimeout(() => { $("#btn-copy-key").textContent = "Copier"; }, 1500);
    } catch {
      prompt("Copie la clé:", v);
    }
  });

  $("#keys-list")?.addEventListener("click", async (e) => {
    const btn = e.target.closest("[data-revoke]");
    if (!btn) return;
    if (!confirm("Révoquer cette clé ?")) return;
    await fetch("/api/keys/revoke", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ key: btn.dataset.revoke }),
    });
    loadSettingsUI();
  });

  $("#btn-save-settings")?.addEventListener("click", async () => {
    try {
      await fetch("/api/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          require_api_key: $("#opt-require-key").checked,
          max_results: parseInt($("#opt-max-results").value, 10),
        }),
      });
      alert("Paramètres enregistrés.");
      loadSettingsUI();
    } catch (e) {
      alert("Erreur: " + e.message);
    }
  });

  // Events
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const q = input.value.trim();
    if (q) search(q);
  });
  resultsEl.addEventListener("click", onCard);
  libraryEl.addEventListener("click", onCard);

  document.querySelectorAll(".tab").forEach((tab) => {
    tab.addEventListener("click", () => switchTab(tab.dataset.tab));
  });
  $("#btn-lib").addEventListener("click", () => switchTab("library"));
  $("#btn-settings").addEventListener("click", () => switchTab("settings"));
  $("#btn-clear-lib").addEventListener("click", () => {
    saveLib([]);
    renderLibrary();
  });
  document.querySelectorAll(".chip").forEach((chip) => {
    chip.addEventListener("click", () => {
      document.querySelectorAll(".chip").forEach((c) => c.classList.remove("active"));
      chip.classList.add("active");
      sortMode = chip.dataset.sort || "pop";
      if (tracks.length) render();
    });
  });
  $("#player-close").addEventListener("click", (e) => {
    e.preventDefault();
    e.stopPropagation();
    try { audio.pause(); audio.removeAttribute("src"); audio.load(); } catch {}
    player.hidden = true;
    player.style.display = "none";
  });
  $("#btn-theme").addEventListener("click", () => {
    const root = document.documentElement;
    const next = root.getAttribute("data-theme") === "light" ? "dark" : "light";
    if (next === "light") root.setAttribute("data-theme", "light");
    else root.removeAttribute("data-theme");
    localStorage.setItem("nm-theme", next);
  });
  if (localStorage.getItem("nm-theme") === "light") {
    document.documentElement.setAttribute("data-theme", "light");
  }
  $("#lyrics-close").addEventListener("click", (e) => {
    e.preventDefault();
    e.stopPropagation();
    // X ferme TOUJOURS, même si épinglé
    lyricsPinned = false;
    lyricsPanel.classList.remove("pinned");
    const pin = $("#lyrics-pin");
    if (pin) pin.classList.remove("active");
    lyricsPanel.hidden = true;
    lyricsPanel.style.display = "none";
  });
  $("#lyrics-pin").addEventListener("click", (e) => {
    e.preventDefault();
    e.stopPropagation();
    lyricsPinned = !lyricsPinned;
    lyricsPanel.classList.toggle("pinned", lyricsPinned);
    $("#lyrics-pin").classList.toggle("active", lyricsPinned);
  });

  if (IS_HTTP) {
    fetch("/api/ping")
      .then((r) => r.json())
      .then((d) => {
        setStatus(
          d.ytdlp
            ? "Prêt v" + (d.version || "3.0") + " — yt-dlp OK. Recherche une musique."
            : "⚠ yt-dlp manquant : pip install yt-dlp puis relance le serveur.",
          d.ytdlp ? "ok" : "error"
        );
      })
      .catch(() => setStatus("Serveur injoignable.", "error"));
  } else {
    setStatus("⚠️ Lance python server.py", "error");
  }
  input.focus();
  renderLibrary();
})();
